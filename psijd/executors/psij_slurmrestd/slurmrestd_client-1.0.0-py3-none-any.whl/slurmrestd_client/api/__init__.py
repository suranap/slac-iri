# flake8: noqa

# import apis into api package
from slurmrestd_client.api.slurm_api import SlurmApi
from slurmrestd_client.api.slurmdb_api import SlurmdbApi

